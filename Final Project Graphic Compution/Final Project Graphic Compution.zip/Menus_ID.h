#pragma once

int color_Menu_ID;

/**********************************************************************/
int perspective_Menu_ID;

/**********************************************************************/
int animation_Menu_ID;

/**********************************************************************/
int animation_Entrance_Doors_Menu_ID;
int animation_Delivery_Doors_Menu_ID;
int animation_Both_Doors_Menu_ID;

/**********************************************************************/
int perspective_2D_Menu_ID;
int regular_Perspective_2D_Menu_ID;
int irregular_Perspective_2D_Menu_ID;
int irregular_Full_Perspective_2D_Menu_ID;

/**********************************************************************/
int cut_Perspective_2D_Menu_ID;
int full_Perspective_2D_Menu_ID;

/**********************************************************************/
int entrance_Perspective_2D_Menu_ID;
int hallway_Perspective_2D_Menu_ID;
int courtyard_Perspective_2D_Menu_ID;
int main_Building_Perspective_2D_Menu_ID;
int delivery_Door_Perspective_2D_Menu_ID;
int castle_Perspective_2D_Menu_ID;

/**********************************************************************/
int entrance_Full_Perspective_2D_Menu_ID;
int hallway_Full_Perspective_2D_Menu_ID;
int courtyard_Full_Perspective_2D_Menu_ID;
int main_Building_Full_Perspective_2D_Menu_ID;
int delivery_Door_Full_Perspective_2D_Menu_ID;
int castle_Full_Perspective_2D_Menu_ID;

/**********************************************************************/
int perspective_3D_Menu_ID;
int regular_Perspective_3D_Menu_ID;
int irregular_Perspective_3D_Menu_ID;
int irregular_Full_Perspective_3D_Menu_ID;

/**********************************************************************/
int cut_Perspective_3D_Menu_ID;
int full_Perspective_3D_Menu_ID;

/**********************************************************************/
int entrance_Perspective_3D_Menu_ID;
int hallway_Perspective_3D_Menu_ID;
int courtyard_Perspective_3D_Menu_ID;
int main_Building_Perspective_3D_Menu_ID;
int delivery_Door_Perspective_3D_Menu_ID;
int castle_Perspective_3D_Menu_ID;

/**********************************************************************/
int entrance_Full_Perspective_3D_Menu_ID;
int hallway_Full_Perspective_3D_Menu_ID;
int courtyard_Full_Perspective_3D_Menu_ID;
int main_Building_Full_Perspective_3D_Menu_ID;
int delivery_Door_Full_Perspective_3D_Menu_ID;
int castle_Full_Perspective_3D_Menu_ID;
