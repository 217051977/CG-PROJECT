#pragma once

void setPerspective_Castle(int option) {

	switch (option) {

		//      front
	case 37: {

		setFrontPerspective_Castle();

	}break;

		//      back
	case 38: {

		setFrontPerspective_Castle();

	}break;

		//      Left
	case 39: {

		setFrontPerspective_Castle();

	}break;

		//      Right
	case 40: {

		setFrontPerspective_Castle();

	}break;

		//      Top
	case 41: {

		setFrontPerspective_Castle();

	}break;

		//      Bot
	case 42: {

		setFrontPerspective_Castle();

	}break;

	}

}