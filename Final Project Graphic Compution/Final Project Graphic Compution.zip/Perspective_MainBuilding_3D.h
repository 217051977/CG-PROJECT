#pragma once

void setFrontPerspective_Main_Building() {}

void setBackPerspective_Main_Building() {}

void setLeftPerspective_Main_Building() {}

void setRightPerspective_Main_Building() {}

void setTopPerspective_Main_Building() {}

void setBotPerspective_Main_Building() {}