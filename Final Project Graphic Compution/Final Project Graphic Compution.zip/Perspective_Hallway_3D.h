#pragma once

void setFrontPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}

void setBackPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}

void setLeftPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}

void setRightPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}

void setTopPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}

void setBotPerspective_Hallway() {

	gluPerspective(150, 1, 1, 1000);

}