/***********************************************************************************************************************
*                                                                                                                      *
*                                               MiddleTowersConnection.h                                               *
*                                                                                                                      *
*                                  This file is responsible to create the arc bridge                                   *
*                                                                                                                      *
************************************************************************************************************************
*                                                                         *                                            *
*                               GROUP MEMBERS:                            *         GROUP MEMBERS' NUMBERS:            *
*                                                                         *                                            *
*                           Bruno Miguel Dias Leal                        *               N� 21705197                  *
*              Diana Margarida Sim�es Soares da Silva de Jesus            *               N� 21703012                  *
*                                                                         *                                            *
***********************************************************************************************************************/

//makes the program where this header will be used add it just one time this header to it
#pragma once
