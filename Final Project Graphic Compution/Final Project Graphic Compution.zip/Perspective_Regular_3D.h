#pragma once

void setFrontPerspective() {

	gluPerspective(150, 1, 1, 1000);

}

void setBackPerspective() {

    gluPerspective(150, 1, 1, 1000);

}

void setLeftPerspective() {

    gluPerspective(150, 1, 1, 1000);

}

void setRightPerspective() {

	gluPerspective(150, 1, 1, 1000);

}

void setTopPerspective() {

	gluPerspective(150, 1, 1, 1000);

}

void setBotPerspective() {

	gluPerspective(150, 1, 1, 1000);

}