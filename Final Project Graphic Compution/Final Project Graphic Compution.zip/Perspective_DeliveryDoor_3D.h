#pragma once

void setFrontPerspective_Delivery_Door() {}

void setBackPerspective_Delivery_Door() {}

void setLeftPerspective_Delivery_Door() {}

void setRightPerspective_Delivery_Door() {}

void setTopPerspective_Delivery_Door() {}

void setBotPerspective_Delivery_Door() {}