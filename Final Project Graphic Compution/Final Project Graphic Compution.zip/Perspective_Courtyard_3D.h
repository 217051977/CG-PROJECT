#pragma once

void setFrontPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 1000);

}

void setBackPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 140);

}

void setLeftPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 480);

}

void setRightPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 480);

}

void setTopPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 1000);

}

void setBotPerspective_Courtyard() {

    gluPerspective(150, 1, 1, 1000);

}