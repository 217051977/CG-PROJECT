#pragma once

void setPerspective_Delivery_Door(int option) {

	switch (option) {

		//      front
	case 31: {

		setFrontPerspective_Delivery_Door();

	}break;

		//      back
	case 32: {

		setFrontPerspective_Delivery_Door();

	}break;

		//      Left
	case 33: {

		setFrontPerspective_Delivery_Door();

	}break;

		//      Right
	case 34: {

		setFrontPerspective_Delivery_Door();

	}break;

		//      Top
	case 35: {

		setFrontPerspective_Delivery_Door();

	}break;

		//      Bot
	case 36: {

		setFrontPerspective_Delivery_Door();

	}break;

	}

}