#pragma once

void setFrontPerspective_Castle() {}

void setBackPerspective_Castle() {}

void setLeftPerspective_Castle() {}

void setRightPerspective_Castle() {}

void setTopPerspective_Castle() {}

void setBotPerspective_Castle() {}