#pragma once

void setFrontPerspective_Entrance() {

	gluPerspective(150, 1, 1, 1000);

}

void setBackPerspective_Entrance() {

	gluPerspective(150, 1, 1, 140);

}

void setLeftPerspective_Entrance() {

	gluPerspective(150, 1, 1, 480);

}

void setRightPerspective_Entrance() {

	gluPerspective(150, 1, 1, 480);

}

void setTopPerspective_Entrance() {

	gluPerspective(150, 1, 1, 1000);

}

void setBotPerspective_Entrance() {

	gluPerspective(150, 1, 1, 1000);

}